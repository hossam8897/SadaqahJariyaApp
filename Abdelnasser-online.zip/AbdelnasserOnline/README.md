# Abdelnasser Memorial Android App

Standalone Android wrapper for https://abdelnasser.autocoder.store.

- Does not launch Google Chrome.
- Uses Android's embedded System WebView.
- Keeps HTTP/HTTPS navigation inside the app.
- RTL-compatible and full-screen content area.
- Android 6.0+ (API 23), target SDK 35.

Build with Android Studio and generate a signed APK/AAB.
