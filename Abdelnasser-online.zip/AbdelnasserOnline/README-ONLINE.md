# Abdelnasser App — online APK build

This project can be built from a phone using GitHub Actions. No Android Studio is required.

1. Create a GitHub repository.
2. Upload the contents of this folder to the repository (including `.github/workflows/build-apk.yml`).
3. Open **Actions** → **Build APK** → **Run workflow**.
4. When it finishes, open the workflow run → **Artifacts** → download `AbdelnasserApp-debug-apk`.
5. Unzip the artifact on the phone; the APK inside is `app-debug.apk`.
