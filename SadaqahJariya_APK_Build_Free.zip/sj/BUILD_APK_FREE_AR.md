# بناء APK مجانًا

أسهل طريقة بدون دفع هي GitHub Actions على مستودع عام.

1. أنشئ حسابًا مجانيًا على GitHub.
2. أنشئ Repository جديدًا واجعله Public.
3. ارفع كل ملفات هذا المشروع إلى المستودع، خصوصًا مجلد `.github/workflows`.
4. افتح تبويب **Actions** ثم اختر **Build APK** ثم **Run workflow**.
5. بعد نجاح التشغيل، افتح آخر عملية Build وانزل إلى **Artifacts**.
6. حمّل `sadaqah-jariya-apk` وفك الضغط؛ ستجد `app-debug.apk`.
7. انقل APK إلى هاتفك وثبّته.

البناء يتم باستخدام Gradle وAndroid SDK، ولا يحتاج اشتراكًا مدفوعًا إذا استخدمت مستودعًا عامًا.
