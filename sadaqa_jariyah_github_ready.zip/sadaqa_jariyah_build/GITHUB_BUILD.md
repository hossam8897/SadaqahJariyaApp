# GitHub Build

هذه النسخة تحافظ على ملفات التطبيق الحالية كما هي، وتضيف إعداد GitHub Actions.

بعد رفع المشروع إلى GitHub:
1. افتح Actions.
2. شغّل Build Android APK من Run workflow.
3. بعد نجاح البناء ستجد APK داخل Artifacts باسم sadaqa-jariyah-apk.

مجلد Android لم يتم إدخاله يدويًا حتى لا نغيّر ملفات التطبيق الحالية؛ يتم إنشاؤه تلقائيًا أثناء البناء بواسطة Flutter.
