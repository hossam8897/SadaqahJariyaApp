import 'package:shared_preferences/shared_preferences.dart';

class StorageService {
  final SharedPreferences _prefs;

  StorageService(this._prefs);

  int getTasbihCount() => _prefs.getInt('tasbih_count') ?? 0;
  Future<void> setTasbihCount(int value) => _prefs.setInt('tasbih_count', value);
  Future<void> resetTasbih() => _prefs.setInt('tasbih_count', 0);

  int getKhatmaProgress() => _prefs.getInt('khatma_progress') ?? 0;
  Future<void> setKhatmaProgress(int value) => _prefs.setInt('khatma_progress', value);

  String getCustomDua() => _prefs.getString('custom_dua') ??
      'اللهم اغفر لعبدك عبدالناصر عمران وارحمه وعافه واعف عنه، وأكرم نزله ووسع مدخله، واغسله بالماء والثلج والبرد، ونقه من الخطايا كما ينقى الثوب الأبيض من الدنس، وأبدله داراً خيراً من داره وأهلاً خيراً من أهله وزوجاً خيراً من زوجه، وأدخله الجنة وأعذه من عذاب القبر ومن عذاب النار.';

  Future<void> setCustomDua(String value) => _prefs.setString('custom_dua', value);

  int getAdhkarProgress(String key) => _prefs.getInt('adhkar_$key') ?? 0;
  Future<void> setAdhkarProgress(String key, int value) => _prefs.setInt('adhkar_$key', value);
  Future<void> resetAdhkarProgress(String key) => _prefs.setInt('adhkar_$key', 0);
}
