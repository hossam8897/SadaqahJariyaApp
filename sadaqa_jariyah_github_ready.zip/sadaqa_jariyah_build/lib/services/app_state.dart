import 'package:flutter/foundation.dart';
import 'storage_service.dart';

class AppState extends ChangeNotifier {
  final StorageService storage;

  AppState(this.storage) {
    _tasbihCount = storage.getTasbihCount();
    _khatmaProgress = storage.getKhatmaProgress();
    _customDua = storage.getCustomDua();
  }

  int _tasbihCount = 0;
  int get tasbihCount => _tasbihCount;

  int _khatmaProgress = 0;
  int get khatmaProgress => _khatmaProgress;

  String _customDua = '';
  String get customDua => _customDua;

  Future<void> incrementTasbih() async {
    _tasbihCount++;
    await storage.setTasbihCount(_tasbihCount);
    notifyListeners();
  }

  Future<void> resetTasbih() async {
    _tasbihCount = 0;
    await storage.resetTasbih();
    notifyListeners();
  }

  Future<void> updateKhatma(int value) async {
    _khatmaProgress = value;
    await storage.setKhatmaProgress(value);
    notifyListeners();
  }

  Future<void> updateCustomDua(String value) async {
    _customDua = value;
    await storage.setCustomDua(value);
    notifyListeners();
  }
}
