import 'package:flutter/material.dart';
import 'tasbih_screen.dart';
import 'adhkar_screen.dart';
import 'asma_screen.dart';
import 'duas_screen.dart';
import 'qibla_screen.dart';
import 'prayer_times_screen.dart';
import 'quran_screen.dart';
import 'khatma_screen.dart';
import 'special_dua_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 220,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              centerTitle: true,
              title: const Text(
                'صدقة جارية',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  shadows: [Shadow(blurRadius: 8, color: Colors.black54)],
                ),
              ),
              background: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Color(0xFF0D7377),
                      Color(0xFF14919B),
                      Color(0xFF0A5C5F),
                    ],
                  ),
                ),
                child: SafeArea(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SizedBox(height: 20),
                      const Icon(Icons.favorite, color: Colors.white70, size: 36),
                      const SizedBox(height: 8),
                      const Text(
                        'على روح',
                        style: TextStyle(color: Colors.white70, fontSize: 16),
                      ),
                      const Text(
                        'عبدالناصر عمران',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 26,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.white24,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: const Text(
                          'اللهم اجعل هذا العمل في ميزان حسناته',
                          style: TextStyle(color: Colors.white, fontSize: 13),
                        ),
                      ),
                      const SizedBox(height: 40),
                    ],
                  ),
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 20, 16, 8),
              child: Card(
                color: const Color(0xFF0D7377),
                child: InkWell(
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const SpecialDuaScreen()),
                  ),
                  borderRadius: BorderRadius.circular(16),
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Colors.white24,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(
                            Icons.volunteer_activism,
                            color: Colors.white,
                            size: 32,
                          ),
                        ),
                        const SizedBox(width: 16),
                        const Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'الدعاء على روح عبدالناصر',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(height: 4),
                              Text(
                                'ادعُ له وشارك الدعاء',
                                style: TextStyle(
                                  color: Colors.white70,
                                  fontSize: 14,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const Icon(
                          Icons.arrow_back_ios,
                          color: Colors.white70,
                          size: 18,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.all(12),
            sliver: SliverGrid(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 1.15,
              ),
              delegate: SliverChildListDelegate([
                _FeatureCard(
                  title: 'المسبحة',
                  icon: Icons.radio_button_checked,
                  color: const Color(0xFF2E7D32),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const TasbihScreen()),
                  ),
                ),
                _FeatureCard(
                  title: 'أذكار الصباح والمساء',
                  icon: Icons.wb_sunny_outlined,
                  color: const Color(0xFFF57C00),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const AdhkarScreen()),
                  ),
                ),
                _FeatureCard(
                  title: 'أسماء الله الحسنى',
                  icon: Icons.auto_awesome,
                  color: const Color(0xFF6A1B9A),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const AsmaScreen()),
                  ),
                ),
                _FeatureCard(
                  title: 'الأدعية',
                  icon: Icons.menu_book,
                  color: const Color(0xFF1565C0),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const DuasScreen()),
                  ),
                ),
                _FeatureCard(
                  title: 'اتجاه القبلة',
                  icon: Icons.explore,
                  color: const Color(0xFF00838F),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const QiblaScreen()),
                  ),
                ),
                _FeatureCard(
                  title: 'مواقيت الصلاة',
                  icon: Icons.access_time,
                  color: const Color(0xFFAD1457),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const PrayerTimesScreen(),
                    ),
                  ),
                ),
                _FeatureCard(
                  title: 'القرآن الكريم',
                  icon: Icons.book,
                  color: const Color(0xFF00695C),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const QuranScreen()),
                  ),
                ),
                _FeatureCard(
                  title: 'ختمة القرآن',
                  icon: Icons.checklist,
                  color: const Color(0xFF5D4037),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const KhatmaScreen()),
                  ),
                ),
              ]),
            ),
          ),
          const SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.symmetric(vertical: 24),
              child: Column(
                children: [
                  Text(
                    'اللهم تقبل منا ومنك',
                    style: TextStyle(fontSize: 16, color: Colors.grey),
                  ),
                  SizedBox(height: 4),
                  Text(
                    'صدقة جارية على روح عبدالناصر عمران',
                    style: TextStyle(fontSize: 13, color: Colors.grey),
                  ),
                  SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _FeatureCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const _FeatureCard({
    required this.title,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 3,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [color.withOpacity(0.9), color],
            ),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 42, color: Colors.white),
              const SizedBox(height: 12),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: Text(
                  title,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
