import 'package:flutter/material.dart';
import 'package:quran/quran.dart' as quran;

class Surah {
  final int number;
  final String name;
  final int ayahs;
  final String type;

  const Surah({
    required this.number,
    required this.name,
    required this.ayahs,
    required this.type,
  });
}

const List<Surah> surahs = [
  Surah(number: 1, name: 'الفاتحة', ayahs: 7, type: 'مكية'),
  Surah(number: 2, name: 'البقرة', ayahs: 286, type: 'مدنية'),
  Surah(number: 3, name: 'آل عمران', ayahs: 200, type: 'مدنية'),
  Surah(number: 4, name: 'النساء', ayahs: 176, type: 'مدنية'),
  Surah(number: 5, name: 'المائدة', ayahs: 120, type: 'مدنية'),
  Surah(number: 6, name: 'الأنعام', ayahs: 165, type: 'مكية'),
  Surah(number: 7, name: 'الأعراف', ayahs: 206, type: 'مكية'),
  Surah(number: 8, name: 'الأنفال', ayahs: 75, type: 'مدنية'),
  Surah(number: 9, name: 'التوبة', ayahs: 129, type: 'مدنية'),
  Surah(number: 10, name: 'يونس', ayahs: 109, type: 'مكية'),
  Surah(number: 11, name: 'هود', ayahs: 123, type: 'مكية'),
  Surah(number: 12, name: 'يوسف', ayahs: 111, type: 'مكية'),
  Surah(number: 13, name: 'الرعد', ayahs: 43, type: 'مدنية'),
  Surah(number: 14, name: 'إبراهيم', ayahs: 52, type: 'مكية'),
  Surah(number: 15, name: 'الحجر', ayahs: 99, type: 'مكية'),
  Surah(number: 16, name: 'النحل', ayahs: 128, type: 'مكية'),
  Surah(number: 17, name: 'الإسراء', ayahs: 111, type: 'مكية'),
  Surah(number: 18, name: 'الكهف', ayahs: 110, type: 'مكية'),
  Surah(number: 19, name: 'مريم', ayahs: 98, type: 'مكية'),
  Surah(number: 20, name: 'طه', ayahs: 135, type: 'مكية'),
  Surah(number: 21, name: 'الأنبياء', ayahs: 112, type: 'مكية'),
  Surah(number: 22, name: 'الحج', ayahs: 78, type: 'مدنية'),
  Surah(number: 23, name: 'المؤمنون', ayahs: 118, type: 'مكية'),
  Surah(number: 24, name: 'النور', ayahs: 64, type: 'مدنية'),
  Surah(number: 25, name: 'الفرقان', ayahs: 77, type: 'مكية'),
  Surah(number: 26, name: 'الشعراء', ayahs: 227, type: 'مكية'),
  Surah(number: 27, name: 'النمل', ayahs: 93, type: 'مكية'),
  Surah(number: 28, name: 'القصص', ayahs: 88, type: 'مكية'),
  Surah(number: 29, name: 'العنكبوت', ayahs: 69, type: 'مكية'),
  Surah(number: 30, name: 'الروم', ayahs: 60, type: 'مكية'),
  Surah(number: 31, name: 'لقمان', ayahs: 34, type: 'مكية'),
  Surah(number: 32, name: 'السجدة', ayahs: 30, type: 'مكية'),
  Surah(number: 33, name: 'الأحزاب', ayahs: 73, type: 'مدنية'),
  Surah(number: 34, name: 'سبأ', ayahs: 54, type: 'مكية'),
  Surah(number: 35, name: 'فاطر', ayahs: 45, type: 'مكية'),
  Surah(number: 36, name: 'يس', ayahs: 83, type: 'مكية'),
  Surah(number: 37, name: 'الصافات', ayahs: 182, type: 'مكية'),
  Surah(number: 38, name: 'ص', ayahs: 88, type: 'مكية'),
  Surah(number: 39, name: 'الزمر', ayahs: 75, type: 'مكية'),
  Surah(number: 40, name: 'غافر', ayahs: 85, type: 'مكية'),
  Surah(number: 41, name: 'فصلت', ayahs: 54, type: 'مكية'),
  Surah(number: 42, name: 'الشورى', ayahs: 53, type: 'مكية'),
  Surah(number: 43, name: 'الزخرف', ayahs: 89, type: 'مكية'),
  Surah(number: 44, name: 'الدخان', ayahs: 59, type: 'مكية'),
  Surah(number: 45, name: 'الجاثية', ayahs: 37, type: 'مكية'),
  Surah(number: 46, name: 'الأحقاف', ayahs: 35, type: 'مكية'),
  Surah(number: 47, name: 'محمد', ayahs: 38, type: 'مدنية'),
  Surah(number: 48, name: 'الفتح', ayahs: 29, type: 'مدنية'),
  Surah(number: 49, name: 'الحجرات', ayahs: 18, type: 'مدنية'),
  Surah(number: 50, name: 'ق', ayahs: 45, type: 'مكية'),
  Surah(number: 51, name: 'الذاريات', ayahs: 60, type: 'مكية'),
  Surah(number: 52, name: 'الطور', ayahs: 49, type: 'مكية'),
  Surah(number: 53, name: 'النجم', ayahs: 62, type: 'مكية'),
  Surah(number: 54, name: 'القمر', ayahs: 55, type: 'مكية'),
  Surah(number: 55, name: 'الرحمن', ayahs: 78, type: 'مدنية'),
  Surah(number: 56, name: 'الواقعة', ayahs: 96, type: 'مكية'),
  Surah(number: 57, name: 'الحديد', ayahs: 29, type: 'مدنية'),
  Surah(number: 58, name: 'المجادلة', ayahs: 22, type: 'مدنية'),
  Surah(number: 59, name: 'الحشر', ayahs: 24, type: 'مدنية'),
  Surah(number: 60, name: 'الممتحنة', ayahs: 13, type: 'مدنية'),
  Surah(number: 61, name: 'الصف', ayahs: 14, type: 'مدنية'),
  Surah(number: 62, name: 'الجمعة', ayahs: 11, type: 'مدنية'),
  Surah(number: 63, name: 'المنافقون', ayahs: 11, type: 'مدنية'),
  Surah(number: 64, name: 'التغابن', ayahs: 18, type: 'مدنية'),
  Surah(number: 65, name: 'الطلاق', ayahs: 12, type: 'مدنية'),
  Surah(number: 66, name: 'التحريم', ayahs: 12, type: 'مدنية'),
  Surah(number: 67, name: 'الملك', ayahs: 30, type: 'مكية'),
  Surah(number: 68, name: 'القلم', ayahs: 52, type: 'مكية'),
  Surah(number: 69, name: 'الحاقة', ayahs: 52, type: 'مكية'),
  Surah(number: 70, name: 'المعارج', ayahs: 44, type: 'مكية'),
  Surah(number: 71, name: 'نوح', ayahs: 28, type: 'مكية'),
  Surah(number: 72, name: 'الجن', ayahs: 28, type: 'مكية'),
  Surah(number: 73, name: 'المزمل', ayahs: 20, type: 'مكية'),
  Surah(number: 74, name: 'المدثر', ayahs: 56, type: 'مكية'),
  Surah(number: 75, name: 'القيامة', ayahs: 40, type: 'مكية'),
  Surah(number: 76, name: 'الإنسان', ayahs: 31, type: 'مدنية'),
  Surah(number: 77, name: 'المرسلات', ayahs: 50, type: 'مكية'),
  Surah(number: 78, name: 'النبأ', ayahs: 40, type: 'مكية'),
  Surah(number: 79, name: 'النازعات', ayahs: 46, type: 'مكية'),
  Surah(number: 80, name: 'عبس', ayahs: 42, type: 'مكية'),
  Surah(number: 81, name: 'التكوير', ayahs: 29, type: 'مكية'),
  Surah(number: 82, name: 'الانفطار', ayahs: 19, type: 'مكية'),
  Surah(number: 83, name: 'المطففين', ayahs: 36, type: 'مكية'),
  Surah(number: 84, name: 'الانشقاق', ayahs: 25, type: 'مكية'),
  Surah(number: 85, name: 'البروج', ayahs: 22, type: 'مكية'),
  Surah(number: 86, name: 'الطارق', ayahs: 17, type: 'مكية'),
  Surah(number: 87, name: 'الأعلى', ayahs: 19, type: 'مكية'),
  Surah(number: 88, name: 'الغاشية', ayahs: 26, type: 'مكية'),
  Surah(number: 89, name: 'الفجر', ayahs: 30, type: 'مكية'),
  Surah(number: 90, name: 'البلد', ayahs: 20, type: 'مكية'),
  Surah(number: 91, name: 'الشمس', ayahs: 15, type: 'مكية'),
  Surah(number: 92, name: 'الليل', ayahs: 21, type: 'مكية'),
  Surah(number: 93, name: 'الضحى', ayahs: 11, type: 'مكية'),
  Surah(number: 94, name: 'الشرح', ayahs: 8, type: 'مكية'),
  Surah(number: 95, name: 'التين', ayahs: 8, type: 'مكية'),
  Surah(number: 96, name: 'العلق', ayahs: 19, type: 'مكية'),
  Surah(number: 97, name: 'القدر', ayahs: 5, type: 'مكية'),
  Surah(number: 98, name: 'البينة', ayahs: 8, type: 'مدنية'),
  Surah(number: 99, name: 'الزلزلة', ayahs: 8, type: 'مدنية'),
  Surah(number: 100, name: 'العاديات', ayahs: 11, type: 'مكية'),
  Surah(number: 101, name: 'القارعة', ayahs: 11, type: 'مكية'),
  Surah(number: 102, name: 'التكاثر', ayahs: 8, type: 'مكية'),
  Surah(number: 103, name: 'العصر', ayahs: 3, type: 'مكية'),
  Surah(number: 104, name: 'الهمزة', ayahs: 9, type: 'مكية'),
  Surah(number: 105, name: 'الفيل', ayahs: 5, type: 'مكية'),
  Surah(number: 106, name: 'قريش', ayahs: 4, type: 'مكية'),
  Surah(number: 107, name: 'الماعون', ayahs: 7, type: 'مكية'),
  Surah(number: 108, name: 'الكوثر', ayahs: 3, type: 'مكية'),
  Surah(number: 109, name: 'الكافرون', ayahs: 6, type: 'مكية'),
  Surah(number: 110, name: 'النصر', ayahs: 3, type: 'مدنية'),
  Surah(number: 111, name: 'المسد', ayahs: 5, type: 'مكية'),
  Surah(number: 112, name: 'الإخلاص', ayahs: 4, type: 'مكية'),
  Surah(number: 113, name: 'الفلق', ayahs: 5, type: 'مكية'),
  Surah(number: 114, name: 'الناس', ayahs: 6, type: 'مكية'),
];

class QuranScreen extends StatelessWidget {
  const QuranScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('القرآن الكريم')),
      body: ListView.builder(
        padding: const EdgeInsets.symmetric(vertical: 8),
        itemCount: surahs.length,
        itemBuilder: (context, index) {
          final surah = surahs[index];

          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: const Color(0xFF0D7377),
                child: Text(
                  '${surah.number}',
                  style: const TextStyle(color: Colors.white, fontSize: 14),
                ),
              ),
              title: Text(
                surah.name,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              subtitle: Text('${surah.ayahs} آية • ${surah.type}'),
              trailing: const Icon(Icons.arrow_back_ios, size: 16),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => SurahReaderScreen(surah: surah),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}

class SurahReaderScreen extends StatelessWidget {
  final Surah surah;

  const SurahReaderScreen({
    super.key,
    required this.surah,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('سورة ${surah.name}')),
      body: ListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 30),
        itemCount: surah.ayahs + 1,
        itemBuilder: (context, index) {
          if (index == 0) {
            return Column(
              children: [
                Text(
                  'سورة ${surah.name}',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF0D7377),
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  '${surah.type} • ${surah.ayahs} آية',
                  style: TextStyle(color: Colors.grey[600], fontSize: 15),
                ),
                const SizedBox(height: 20),
                if (surah.number != 9)
                  const Text(
                    'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 23,
                      fontWeight: FontWeight.bold,
                      height: 2,
                    ),
                  ),
                const SizedBox(height: 18),
              ],
            );
          }

          final ayahNumber = index;
          final ayahText = quran.getVerse(
            surah.number,
            ayahNumber,
            verseEndSymbol: true,
          );

          return Container(
            margin: const EdgeInsets.only(bottom: 14),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFFF7FAFA),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: const Color(0xFF0D7377).withOpacity(0.12),
              ),
            ),
            child: Text(
              ayahText,
              textDirection: TextDirection.rtl,
              textAlign: TextAlign.right,
              style: const TextStyle(
                fontSize: 22,
                height: 2.0,
              ),
            ),
          );
        },
      ),
    );
  }
}
