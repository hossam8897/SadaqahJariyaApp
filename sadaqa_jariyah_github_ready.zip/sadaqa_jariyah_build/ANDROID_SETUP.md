أضف داخل android/app/src/main/AndroidManifest.xml داخل <manifest>:
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
ثم flutter pub get وبعدها flutter build apk --release.
